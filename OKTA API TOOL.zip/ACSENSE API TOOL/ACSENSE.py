# accsense_tab.py

import tkinter as tk
from tkinter import ttk, messagebox
import os
import json
import tkinter.filedialog as fd
import requests
import time
import threading
import platform

################################################################################
# OPTIONAL WINSOUND (disable for non-Windows)
################################################################################

is_windows = platform.system().lower().startswith("win")
try:
    import winsound
except ImportError:
    # Define a no-op winsound fallback
    class _WinSoundStub:
        def Beep(self, freq, dur):
            pass
    winsound = _WinSoundStub()

################################################################################
# GLOBALS & CONFIG
################################################################################

MAX_ACCSENSE_CREDENTIALS = 10
ACCSENSE_CREDENTIALS_FILE = "accsense_credentials.json"

# Holds credentials from disk
accsense_credentials = []

# Global references to UI elements
accsense_credentials_listbox = None
accsense_user_entry = None
accsense_pass_entry = None
accsense_tenant_entry = None  # CIAM Tenant URL (Okta)
accsense_tenant_id_entry = None
accsense_access_token_entry = None
accsense_bearer_token_entry = None
accsense_refresh_token_entry = None  # NEW: For refresh token
accsense_console_text = None
tenant_info_text = None
customers_text = None

# For storing parsed HAR endpoints
parsed_endpoints = []

# References to externally provided callbacks
update_progress_start_ref = None
update_progress_complete_ref = None
log_console_ref = None
validate_okta_url_ref = None
normalize_url_ref = None
run_threaded_ref = None

# For data collection tab
accsense_api_tab = None

# For selecting the instance
instance_var = None
custom_instance = None

# For storing the list of tenants and the current selected tenant
tenant_dropdown_var = None
tenant_dropdown = None
tenant_list = []  # Will hold (tenant_id, tenant_display_name) items
selected_tenant_id = None  # The chosen tenant from dropdown

# For user management
tenant_users_listbox = None
tenant_users = []  # Will store the fetched user objects

# API logging
api_logging_enabled = True
api_logs = []
api_logs_text = None

# For token auto-refresh
auto_refresh_var = None
token_expiry_time = None  # Will track epoch time of next expiration

################################################################################
# UTILITY & LOGGING
################################################################################

def local_log(msg: str):
    """Helper to log to the console text widget locally."""
    global accsense_console_text
    if not accsense_console_text:
        return
    accsense_console_text.configure(state='normal')
    accsense_console_text.insert(tk.END, msg + "\n")
    accsense_console_text.configure(state='disabled')
    accsense_console_text.see(tk.END)

def confirm_action(title: str, message: str) -> bool:
    """Pop up a Yes/No confirmation dialog."""
    return messagebox.askyesno(title, message)

def beep():
    """Plays a short beep on Windows; does nothing on other platforms."""
    if is_windows:
        try:
            winsound.Beep(400, 400)
        except Exception:
            pass

def log_api_request(method, url, request_data, response_status, response_data, error=None):
    """Store and display API logs, with partial redaction of tokens."""
    if not api_logging_enabled:
        return

    # Redact tokens from the request_data / response_data
    def redact_tokens(s):
        if not s:
            return s
        # Very naive approach for demo: replace any "token":"XYZ" or "access_token":"XYZ"
        # More robust approach might involve searching JSON structures or RegEx
        s = s.replace("access_token", "access_token(REDACTED)")
        s = s.replace("refresh_token", "refresh_token(REDACTED)")
        s = s.replace("id_token", "id_token(REDACTED)")
        s = s.replace("Authorization: Bearer", "Authorization: Bearer (REDACTED)")
        return s

    safe_request = ""
    if request_data:
        if isinstance(request_data, dict) or isinstance(request_data, list):
            safe_request = redact_tokens(json.dumps(request_data))
        else:
            safe_request = redact_tokens(str(request_data))

    safe_response = ""
    if isinstance(response_data, dict) or isinstance(response_data, list):
        safe_response = redact_tokens(json.dumps(response_data))
    else:
        safe_response = redact_tokens(str(response_data))

    entry = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "method": method,
        "url": url,
        "request": safe_request,
        "response_status": response_status if response_status else "ERR",
        "response_data": safe_response,
        "error": str(error) if error else ""
    }
    api_logs.append(entry)

    # Also display in UI
    if api_logs_text:
        api_logs_text.configure(state='normal')
        api_logs_text.insert(
            tk.END,
            f"{entry['timestamp']} | {method} {url} -> {entry['response_status']}\n"
        )
        if error:
            api_logs_text.insert(tk.END, f"  ERROR: {error}\n")
        else:
            # Show truncated response
            short_resp = safe_response[:200] + ("..." if len(safe_response) > 200 else "")
            api_logs_text.insert(tk.END, f"  RESP: {short_resp}\n")
        api_logs_text.configure(state='disabled')
        api_logs_text.see(tk.END)

def clear_api_logs():
    """Clears the in-memory logs and the text widget."""
    api_logs.clear()
    if api_logs_text:
        api_logs_text.configure(state='normal')
        api_logs_text.delete("1.0", tk.END)
        api_logs_text.configure(state='disabled')

def accsense_request(method, url, headers=None, data=None, json_data=None, timeout=10):
    """
    Wraps the requests.* calls to provide centralized logging
    and token redaction. Returns (status_code, response_json_or_text, error).
    """
    req_data_for_log = json_data if json_data else data
    response_data = None
    status_code = None
    error = None

    try:
        if method.upper() == "GET":
            resp = requests.get(url, headers=headers, timeout=timeout)
        elif method.upper() == "POST":
            resp = requests.post(url, headers=headers, data=data, json=json_data, timeout=timeout)
        elif method.upper() == "PUT":
            resp = requests.put(url, headers=headers, json=json_data, timeout=timeout)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")

        status_code = resp.status_code
        try:
            response_data = resp.json()
        except:
            response_data = resp.text

    except requests.exceptions.RequestException as ex:
        error = str(ex)

    # Log the request
    log_api_request(
        method, url,
        request_data=req_data_for_log,
        response_status=status_code,
        response_data=response_data,
        error=error
    )
    return (status_code, response_data, error)

################################################################################
# CREDENTIAL MANAGEMENT
################################################################################

def load_accsense_credentials_from_file():
    update_progress_start_ref("Loading Accsense credentials")
    if os.path.exists(ACCSENSE_CREDENTIALS_FILE):
        try:
            with open(ACCSENSE_CREDENTIALS_FILE, 'r', encoding='utf-8') as f:
                creds_data = json.load(f)
            accsense_credentials.clear()
            accsense_credentials.extend(creds_data)
            log_console_ref("Accsense credentials loaded successfully.")
        except Exception as e:
            log_console_ref(f"Error => {e}")
            beep()
    else:
        accsense_credentials.clear()
        log_console_ref("No accsense_credentials.json found; starting empty.")
    update_progress_complete_ref("Loading Accsense credentials")

def save_accsense_credentials_to_file():
    update_progress_start_ref("Saving Accsense credentials")
    try:
        with open(ACCSENSE_CREDENTIALS_FILE, 'w', encoding='utf-8') as f:
            json.dump(accsense_credentials, f, indent=2)
        log_console_ref("Accsense credentials saved successfully.")
    except Exception as e:
        log_console_ref(f"Error => {e}")
        beep()
    update_progress_complete_ref("Saving Accsense credentials")

def update_accsense_credentials_listbox():
    accsense_credentials_listbox.delete(0, tk.END)
    for idx, c in enumerate(accsense_credentials):
        txt = f"{idx+1}. {c['username']} @ {c['tenant_url']}"
        accsense_credentials_listbox.insert(tk.END, txt)
    local_log("Credentials list updated.")

def save_current_accsense_credential():
    username = accsense_user_entry.get().strip()
    password = accsense_pass_entry.get().strip()
    tenant_url = accsense_tenant_entry.get().strip()
    if not (username and password and tenant_url):
        log_console_ref("All fields required.")
        return
    if not validate_okta_url_ref(tenant_url):
        log_console_ref("Tenant URL must start with http:// or https://")
        return
    tenant_url = normalize_url_ref(tenant_url)
    for c in accsense_credentials:
        if c["username"] == username and c["tenant_url"] == tenant_url:
            log_console_ref("Already saved.")
            return
    if len(accsense_credentials) >= MAX_ACCSENSE_CREDENTIALS:
        log_console_ref("Max credentials reached.")
        return
    accsense_credentials.append({
        "username": username,
        "password": password,
        "tenant_url": tenant_url
    })
    save_accsense_credentials_to_file()
    update_accsense_credentials_listbox()
    log_console_ref(f"Accsense credential for user {username} saved successfully.")
    local_log(f"Saving Accsense credential for user {username}...")

def load_selected_accsense_credential():
    try:
        sel = accsense_credentials_listbox.curselection()
        if not sel:
            log_console_ref("No credential selected.")
            return
        idx = sel[0]
        c = accsense_credentials[idx]
        accsense_user_entry.delete(0, tk.END)
        accsense_user_entry.insert(0, c["username"])
        accsense_pass_entry.delete(0, tk.END)
        accsense_pass_entry.insert(0, c["password"])
        accsense_tenant_entry.delete(0, tk.END)
        accsense_tenant_entry.insert(0, c["tenant_url"])
        log_console_ref("Accsense credential loaded.")
    except Exception as e:
        log_console_ref(f"Error => {e}")
        beep()

def delete_selected_accsense_credential():
    try:
        sel = accsense_credentials_listbox.curselection()
        if not sel:
            log_console_ref("No credential selected.")
            return
        idx = sel[0]
        del accsense_credentials[idx]
        save_accsense_credentials_to_file()
        update_accsense_credentials_listbox()
        log_console_ref("Accsense credential deleted.")
    except Exception as e:
        log_console_ref(f"Error => {e}")
        beep()

################################################################################
# AUTHENTICATION & TOKEN MANAGEMENT
################################################################################

def authenticate_accsense():
    """
    Requests tokens from Okta with 'offline_access' scope,
    stores them in the UI fields, and triggers fetching of tenants.
    """
    global token_expiry_time
    update_progress_start_ref("Authenticating with Accsense")
    username = accsense_user_entry.get().strip()
    password = accsense_pass_entry.get().strip()
    tenant_url = accsense_tenant_entry.get().strip()

    if not (username and password and tenant_url):
        log_console_ref("All fields are required.")
        update_progress_complete_ref("Authentication failed")
        return
    if not validate_okta_url_ref(tenant_url):
        log_console_ref("Invalid tenant URL (must start with http:// or https://).")
        update_progress_complete_ref("Authentication failed")
        return

    tenant_url = normalize_url_ref(tenant_url)
    auth_url = f"{tenant_url}/oauth2/default/v1/token"

    payload = {
        "grant_type": "password",
        "username": username,
        "password": password,
        "scope": "openid profile email offline_access"
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json"
    }

    log_console_ref(f"Authenticating => {auth_url}")
    local_log("Starting Accsense authentication...")

    status_code, resp_data, error = accsense_request(
        method="POST",
        url=auth_url,
        headers=headers,
        data=payload
    )
    if error:
        log_console_ref(f"Network/Request Error => {error}")
        beep()
        update_progress_complete_ref("Authentication failed")
        return

    log_console_ref(f"Full Response => {status_code}: {resp_data}")
    if status_code == 200 and isinstance(resp_data, dict):
        access_token = resp_data.get("access_token")
        id_token = resp_data.get("id_token")
        refresh_token = resp_data.get("refresh_token")
        expires_in = resp_data.get("expires_in", 3600)  # default 1 hour

        if access_token:
            # Fill the UI
            accsense_access_token_entry.delete(0, tk.END)
            accsense_access_token_entry.insert(0, access_token)
            if id_token:
                accsense_bearer_token_entry.delete(0, tk.END)
                accsense_bearer_token_entry.insert(0, id_token)
            if refresh_token:
                accsense_refresh_token_entry.delete(0, tk.END)
                accsense_refresh_token_entry.insert(0, refresh_token)
            # Track expiration
            token_expiry_time = time.time() + expires_in
            log_console_ref("Authentication successful. Tokens obtained.")
            local_log("Authentication successful!")
            # After authentication, fetch tenants automatically
            get_tenants_for_dropdown()
        else:
            log_console_ref("Missing access token in response.")
    else:
        log_console_ref(f"Auth failed => {status_code}: {resp_data}")

    update_progress_complete_ref("Authentication complete")

def refresh_accsense_token():
    """
    Uses the refresh token to get a new access token (and new refresh token).
    Updates UI fields accordingly.
    """
    global token_expiry_time
    tenant_url = normalize_url_ref(accsense_tenant_entry.get().strip())
    if not tenant_url:
        log_console_ref("No tenant URL to refresh token.")
        return
    refresh_token = accsense_refresh_token_entry.get().strip()
    if not refresh_token:
        log_console_ref("No refresh token available.")
        return

    auth_url = f"{tenant_url}/oauth2/default/v1/token"
    payload = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "scope": "openid profile email offline_access"
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json"
    }

    log_console_ref("Refreshing access token...")
    status_code, resp_data, error = accsense_request(
        method="POST",
        url=auth_url,
        headers=headers,
        data=payload
    )
    if error:
        log_console_ref(f"Error refreshing token => {error}")
        return
    if status_code == 200 and isinstance(resp_data, dict):
        access_token = resp_data.get("access_token")
        id_token = resp_data.get("id_token")
        new_refresh_token = resp_data.get("refresh_token")
        expires_in = resp_data.get("expires_in", 3600)

        if access_token:
            accsense_access_token_entry.delete(0, tk.END)
            accsense_access_token_entry.insert(0, access_token)
            if id_token:
                accsense_bearer_token_entry.delete(0, tk.END)
                accsense_bearer_token_entry.insert(0, id_token)
            if new_refresh_token:
                accsense_refresh_token_entry.delete(0, tk.END)
                accsense_refresh_token_entry.insert(0, new_refresh_token)
            token_expiry_time = time.time() + expires_in
            log_console_ref("Token refresh successful.")
        else:
            log_console_ref("Missing access token in refresh response.")
    else:
        log_console_ref(f"Token refresh failed => {status_code}: {resp_data}")

def auto_refresh_thread():
    """
    Background thread that periodically checks if the access token is near
    expiration and refreshes it automatically if needed.
    """
    global token_expiry_time
    while True:
        time.sleep(10)  # check every 10 seconds
        if not auto_refresh_var or not auto_refresh_var.get():
            # Auto-refresh turned off or not yet defined
            continue
        if not token_expiry_time:
            # Unknown expiry
            continue
        remaining = token_expiry_time - time.time()
        if remaining < 120:  # less than 2 minutes left
            # Attempt refresh
            refresh_accsense_token()

################################################################################
# TENANT SELECTION
################################################################################

def get_tenants_for_dropdown():
    """
    Immediately fetches the list of tenants (customers) and populates a dropdown
    so the user can select which tenant context to use.
    """
    global tenant_list
    token = accsense_access_token_entry.get().strip()
    if not token:
        log_console_ref("No access token available to fetch tenants.")
        return

    inst = instance_var.get() if instance_var.get() != "custom" else custom_instance.get().strip()
    if not inst.startswith("http"):
        inst = "https://" + inst

    endpoint = f"{inst}/api/v1/customers"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json"
    }
    log_console_ref(f"Fetching tenants from {endpoint}")
    status_code, data, error = accsense_request("GET", endpoint, headers=headers)
    if error:
        log_console_ref(f"Error fetching tenants => {error}")
        return
    if status_code == 200 and isinstance(data, list):
        tenant_list.clear()
        for tenant_obj in data:
            tid = str(tenant_obj.get("id", ""))
            tname = tenant_obj.get("name", "Unknown Tenant")
            tenant_list.append((tid, tname))

        tenant_dropdown_var.set("-- Choose a Tenant --")
        menu = tenant_dropdown["menu"]
        menu.delete(0, "end")

        for (tid, tname) in tenant_list:
            def on_select(val=tid):
                set_selected_tenant(val)
            menu.add_command(label=tname, command=lambda _val=tid: on_select(_val))

        log_console_ref("Tenants loaded into dropdown.")
    else:
        log_console_ref(f"Error => {status_code}: {data}")

def set_selected_tenant(tid):
    global selected_tenant_id
    selected_tenant_id = tid
    # Find matching name to display
    for (_tid, _tname) in tenant_list:
        if (_tid == tid):
            tenant_dropdown_var.set(_tname)
            break
    log_console_ref(f"Selected tenant => {tid}")

################################################################################
# HAR File Functions
################################################################################

def parse_har_file():
    har_path = fd.askopenfilename(
        filetypes=[("HAR files", "*.har"), ("All files", "*.*")]
    )
    if not har_path:
        return
    try:
        with open(har_path, 'r', encoding='utf-8') as f:
            har_data = json.load(f)
        entries = har_data.get("log", {}).get("entries", [])
        parsed_endpoints.clear()
        for e in entries:
            req = e.get("request", {})
            method = req.get("method", "")
            url = req.get("url", "")
            if method and url:
                parsed_endpoints.append((method, url))
        local_log(f"Parsed {len(parsed_endpoints)} endpoints from HAR.")
    except Exception as ex:
        local_log(f"Failed to parse HAR file: {ex}")

def simulate_har_request(method, url):
    token = accsense_access_token_entry.get().strip()
    if not token:
        local_log("Access token is empty.")
        return
    headers = {
        "Authorization": f"Bearer {token}"
    }
    status_code, resp_data, error = accsense_request(method, url, headers=headers)
    if error:
        local_log(f"Error => {error}")
    else:
        local_log(f"Response => {status_code} {resp_data}")

################################################################################
# TENANT INFO & CUSTOMERS
################################################################################

def get_tenant_info():
    """Fetches live tenant configuration information using selected tenant_id."""
    token = accsense_access_token_entry.get().strip()
    tid = selected_tenant_id
    inst = instance_var.get() if instance_var.get() != "custom" else custom_instance.get().strip()
    if not token or not tid or not inst:
        log_console_ref("Missing token, tenant ID, or instance information for tenant info retrieval.")
        return
    if not inst.startswith("http"):
        inst = "https://" + inst

    endpoint = f"{inst}/api/v1/tenant/{tid}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json"
    }
    log_console_ref(f"Fetching tenant info from {endpoint}")
    status_code, data, error = accsense_request("GET", endpoint, headers=headers)
    if error:
        log_console_ref(f"Exception in get_tenant_info: {error}")
        return
    if status_code == 200 and data:
        log_console_ref("Tenant info retrieved successfully.")
        display_tenant_info(data)
    else:
        log_console_ref(f"Error retrieving tenant info: {status_code} - {data}")

def display_tenant_info(tenant_info):
    info_text = json.dumps(tenant_info, indent=2)
    try:
        tenant_info_text.configure(state='normal')
        tenant_info_text.delete("1.0", tk.END)
        tenant_info_text.insert(tk.END, info_text)
        tenant_info_text.configure(state='disabled')
    except Exception as e:
        log_console_ref(f"Error displaying tenant info: {str(e)}")

def get_customers():
    """Fetches the list of customers from the live tenant API."""
    token = accsense_access_token_entry.get().strip()
    inst = instance_var.get() if instance_var.get() != "custom" else custom_instance.get().strip()
    if not token or not inst:
        log_console_ref("Missing token or instance information.")
        return
    if not inst.startswith("http"):
        inst = "https://" + inst

    endpoint = f"{inst}/api/v1/customers"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json"
    }
    log_console_ref(f"Fetching customers from {endpoint}")
    status_code, data, error = accsense_request("GET", endpoint, headers=headers)
    if error:
        log_console_ref(f"Exception in get_customers: {error}")
        return
    if status_code == 200 and isinstance(data, list):
        log_console_ref("Customers retrieved successfully.")
        display_customers(data)
    else:
        log_console_ref(f"Error retrieving customers: {status_code} - {data}")

def display_customers(customers):
    cust_text = json.dumps(customers, indent=2)
    try:
        customers_text.configure(state='normal')
        customers_text.delete("1.0", tk.END)
        customers_text.insert(tk.END, cust_text)
        customers_text.configure(state='disabled')
    except Exception as e:
        log_console_ref(f"Error displaying customers: {str(e)}")

################################################################################
# USER MANAGEMENT (LIST + RESET PASSWORD)
################################################################################

def get_tenant_users():
    """
    Fetches users for the selected tenant from /api/v1/tenant/{tenantId}/users
    (Adjust to your real endpoint).
    """
    global tenant_users
    token = accsense_access_token_entry.get().strip()
    tid = selected_tenant_id
    inst = instance_var.get() if instance_var.get() != "custom" else custom_instance.get().strip()
    if not token or not tid or not inst:
        log_console_ref("Missing token, tenant ID, or instance for user management.")
        return
    if not inst.startswith("http"):
        inst = "https://" + inst

    endpoint = f"{inst}/api/v1/tenant/{tid}/users"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json"
    }
    log_console_ref(f"Fetching users from {endpoint}")
    status_code, data, error = accsense_request("GET", endpoint, headers=headers)
    if error:
        log_console_ref(f"Exception in get_tenant_users: {error}")
        return
    if status_code == 200 and isinstance(data, list):
        tenant_users = data
        log_console_ref("Tenant users retrieved successfully.")
        render_tenant_users()
    else:
        log_console_ref(f"Error retrieving tenant users: {status_code} - {data}")

def render_tenant_users():
    """Displays the user list in the user management listbox."""
    tenant_users_listbox.delete(0, tk.END)
    for user in tenant_users:
        user_id = user.get("id", "??")
        email = user.get("email", "unknown")
        role = user.get("role", "N/A")
        status = user.get("status", "N/A")
        display_txt = f"{user_id} | {email} | {role} | {status}"
        tenant_users_listbox.insert(tk.END, display_txt)

def reset_password_for_selected_user():
    """
    Calls a 'reset password' flow (like Okta's /lifecycle/expire_password) for
    whichever user is selected. Then shows the temporary password if returned.
    """
    sel = tenant_users_listbox.curselection()
    if not sel:
        log_console_ref("No user selected for password reset.")
        return
    user_idx = sel[0]
    user = tenant_users[user_idx]
    user_id = user.get("id")
    if not user_id:
        log_console_ref("Invalid user ID.")
        return

    # Confirm
    if not confirm_action("Confirm Password Reset", f"Are you sure you want to reset password for {user.get('email')}?"):
        return

    token = accsense_access_token_entry.get().strip()
    tid = selected_tenant_id
    inst = instance_var.get() if instance_var.get() != "custom" else custom_instance.get().strip()
    if not token or not tid or not inst:
        log_console_ref("Missing token, tenant ID, or instance for password reset.")
        return
    if not inst.startswith("http"):
        inst = "https://" + inst

    # Example endpoint:
    # POST /api/v1/users/{userId}/lifecycle/expire_password?tempPassword=true
    endpoint = f"{inst}/api/v1/users/{user_id}/lifecycle/expire_password?tempPassword=true"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json"
    }
    log_console_ref(f"Resetting password for user {user_id} via {endpoint}")
    status_code, resp_data, error = accsense_request("POST", endpoint, headers=headers)
    if error:
        log_console_ref(f"Error resetting password => {error}")
        return
    if status_code in [200, 201] and isinstance(resp_data, dict):
        temp_pass = resp_data.get("tempPassword")
        if temp_pass:
            messagebox.showinfo(
                "Temporary Password",
                f"Temporary password generated: {temp_pass}\nUser will be prompted to change on next login."
            )
            log_console_ref("Password reset successful; temp password displayed.")
        else:
            log_console_ref("No tempPassword returned in response.")
    else:
        log_console_ref(f"Error resetting password: {status_code} - {resp_data}")

################################################################################
# HAR & DATA COLLECTION
################################################################################

def clear_console(console):
    console.configure(state='normal')
    console.delete("1.0", tk.END)
    console.configure(state='disabled')

def collect_data(instance, token, data_type):
    """Collect data from the specified Accsense instance."""
    if not token:
        log_console_ref("No access token available")
        return
    if not instance:
        log_console_ref("No instance specified")
        return
    local_log(f"Starting data collection from {instance} for {data_type}...")

    if not instance.startswith("http"):
        instance = "https://" + instance

    if data_type == "users":
        endpoint = f"{instance}/api/v1/users"
    elif data_type == "groups":
        endpoint = f"{instance}/api/v1/groups"
    elif data_type == "apps":
        endpoint = f"{instance}/api/v1/apps"
    else:
        log_console_ref(f"Unknown data type: {data_type}")
        return

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json"
    }
    status_code, resp_data, error = accsense_request("GET", endpoint, headers=headers, timeout=30)
    if error:
        log_console_ref(f"Error collecting data => {error}")
        return
    if status_code == 200 and isinstance(resp_data, list):
        local_log(f"Successfully collected {len(resp_data)} {data_type}")
        results_text = json.dumps(resp_data, indent=2)
        display_results(results_text)
        filename = f"accsense_{data_type}_{instance.replace('https://','').replace('http://','').replace('.', '_')}.json"
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(resp_data, f, indent=2)
        log_console_ref(f"Data saved to {filename}")
    else:
        log_console_ref(f"Error collecting data: {status_code} - {resp_data}")

def display_results(text):
    """
    Display results in the Data Collection tab (any text-based widget except the console).
    We look for a text widget that isn't the console or the api_logs_text.
    """
    global accsense_api_tab
    for widget in accsense_api_tab.winfo_children():
        if isinstance(widget, ttk.Notebook):
            for tab_id in widget.tabs():
                tab = widget.nametowidget(tab_id)
                for child in tab.winfo_children():
                    if (isinstance(child, tk.Text) and
                            child != accsense_console_text and
                            child != api_logs_text):
                        child.delete("1.0", tk.END)
                        child.insert(tk.END, text)
                        return

################################################################################
# UI CREATION
################################################################################

def create_endpoints_tab(parent):
    endpoints_frame = tk.Frame(parent)
    upload_button = tk.Button(endpoints_frame, text="Upload HAR", command=parse_har_file)
    upload_button.pack(pady=5)

    endpoints_listbox = tk.Listbox(endpoints_frame, height=10, width=80)
    endpoints_listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def render_endpoints():
        endpoints_listbox.delete(0, tk.END)
        for idx, (method, url) in enumerate(parsed_endpoints):
            endpoints_listbox.insert(tk.END, f"{idx+1}. {method} {url}")

    def run_selected_endpoint():
        try:
            sel = endpoints_listbox.curselection()
            if not sel:
                log_console_ref("No endpoint selected.")
                return
            idx = sel[0]
            method, url = parsed_endpoints[idx]
            simulate_har_request(method, url)
        except Exception as e:
            log_console_ref(f"Error running endpoint: {str(e)}")

    button_frame = tk.Frame(endpoints_frame)
    button_frame.pack(fill=tk.X, pady=5)

    refresh_button = tk.Button(button_frame, text="Refresh Endpoints", command=render_endpoints)
    refresh_button.pack(side=tk.LEFT, padx=5)

    run_button = tk.Button(button_frame, text="Run Selected Endpoint", command=run_selected_endpoint)
    run_button.pack(side=tk.LEFT, padx=5)

    return endpoints_frame

def create_token_management_frame(parent, root):
    """
    A small frame that shows the refresh token, a refresh button, and
    an auto-refresh toggle.
    """
    frame = tk.LabelFrame(parent, text="Token Management", padx=10, pady=10)

    tk.Label(frame, text="Refresh Token:").grid(row=0, column=0, sticky="w", pady=5)
    global accsense_refresh_token_entry
    accsense_refresh_token_entry = tk.Entry(frame, width=80)
    accsense_refresh_token_entry.grid(row=0, column=1, padx=5, pady=5)

    refresh_btn = tk.Button(frame, text="Refresh Token",
                            command=lambda: run_threaded_ref(refresh_accsense_token))
    refresh_btn.grid(row=0, column=2, padx=5, pady=5)

    tk.Label(frame, text="Auto-Refresh Token:").grid(row=1, column=0, sticky="w", pady=5)
    global auto_refresh_var
    auto_refresh_var = tk.BooleanVar(value=False)
    auto_refresh_check = tk.Checkbutton(frame, variable=auto_refresh_var)
    auto_refresh_check.grid(row=1, column=1, sticky="w")

    # Start background thread for auto-refresh
    t = threading.Thread(target=auto_refresh_thread, daemon=True)
    t.start()

    return frame

def create_user_management_tab(parent):
    """
    A tab for listing users under the selected tenant, and resetting passwords.
    """
    user_mgmt_tab = tk.Frame(parent, padx=10, pady=10)

    btn_frame = tk.Frame(user_mgmt_tab)
    btn_frame.pack(anchor="w", fill=tk.X, pady=5)

    fetch_users_btn = tk.Button(
        btn_frame,
        text="Fetch Tenant Users",
        command=lambda: run_threaded_ref(get_tenant_users)
    )
    fetch_users_btn.pack(side=tk.LEFT, padx=5)

    reset_pass_btn = tk.Button(
        btn_frame,
        text="Reset Password",
        command=lambda: run_threaded_ref(reset_password_for_selected_user)
    )
    reset_pass_btn.pack(side=tk.LEFT, padx=5)

    global tenant_users_listbox
    tenant_users_listbox = tk.Listbox(user_mgmt_tab, height=12, width=100)
    tenant_users_listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    return user_mgmt_tab

def create_api_logs_tab(parent):
    """
    A tab to display all API logs with the ability to clear them, or toggle on/off.
    """
    frame = tk.Frame(parent, padx=10, pady=10)
    global api_logs_text
    api_logs_text = tk.Text(frame, height=15, state='disabled')
    api_logs_text.pack(fill=tk.BOTH, expand=True)

    btn_frame = tk.Frame(frame)
    btn_frame.pack(fill=tk.X, pady=5)

    def toggle_logging():
        global api_logging_enabled
        api_logging_enabled = not api_logging_enabled
        status = "ENABLED" if api_logging_enabled else "DISABLED"
        log_console_ref(f"API Logging now {status}.")

    toggle_btn = tk.Button(btn_frame, text="Toggle Logging", command=toggle_logging)
    toggle_btn.pack(side=tk.LEFT, padx=5)

    clear_btn = tk.Button(btn_frame, text="Clear Logs", command=clear_api_logs)
    clear_btn.pack(side=tk.LEFT, padx=5)

    return frame

def create_accsense_api_tab(
    parent,
    root,
    action_buttons,
    log_console,
    run_threaded,
    update_progress_start,
    update_progress_complete,
    validate_okta_url,
    normalize_url
):
    global update_progress_start_ref, update_progress_complete_ref, log_console_ref
    global validate_okta_url_ref, normalize_url_ref, run_threaded_ref
    global accsense_credentials_listbox, accsense_user_entry, accsense_pass_entry
    global accsense_tenant_entry, accsense_tenant_id_entry
    global accsense_access_token_entry, accsense_bearer_token_entry, accsense_console_text
    global accsense_api_tab, instance_var, custom_instance
    global tenant_dropdown, tenant_dropdown_var

    update_progress_start_ref = update_progress_start
    update_progress_complete_ref = update_progress_complete
    log_console_ref = log_console
    validate_okta_url_ref = validate_okta_url
    normalize_url_ref = normalize_url
    run_threaded_ref = run_threaded

    accsense_api_tab = tk.Frame(parent)

    # Create a container at the top to hold left and right frames
    top_container = tk.Frame(parent)
    top_container.pack(fill=tk.X)

    # LEFT FRAME (User/Pass/Tenant/Instance/Credential management)
    left_frame = tk.Frame(top_container, padx=10, pady=10)
    left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Move all username, password, tenant URL, and credential list code into left_frame
    tk.Label(left_frame, text="Accsense Username:").grid(row=0, column=0, sticky="w")
    accsense_user_entry = tk.Entry(left_frame, width=40)
    accsense_user_entry.grid(row=0, column=1, padx=5, pady=2)

    tk.Label(left_frame, text="Accsense Password:").grid(row=1, column=0, sticky="w")
    accsense_pass_entry = tk.Entry(left_frame, width=40, show="*")
    accsense_pass_entry.grid(row=1, column=1, padx=5, pady=2)

    tk.Label(left_frame, text="CIAM Tenant URL:").grid(row=2, column=0, sticky="w")
    accsense_tenant_entry = tk.Entry(left_frame, width=40)
    accsense_tenant_entry.grid(row=2, column=1, padx=5, pady=2)
    tk.Label(left_frame, text="Example: https://yourTenant.okta.com",
             fg="gray").grid(row=3, column=1, sticky="w")

    tk.Label(left_frame, text="Manual Tenant ID:").grid(row=4, column=0, sticky="w")
    accsense_tenant_id_entry = tk.Entry(left_frame, width=40)
    accsense_tenant_id_entry.grid(row=4, column=1, padx=5, pady=2)

    tk.Label(left_frame, text="Accsense Instance:").grid(row=5, column=0, sticky="w")
    instance_frame = tk.Frame(left_frame)
    instance_frame.grid(row=5, column=1, sticky="w")

    instance_var = tk.StringVar(value="europe.accsense.com")
    rb1 = tk.Radiobutton(instance_frame, text="Europe", variable=instance_var, value="europe.accsense.com")
    rb1.pack(side=tk.LEFT)
    rb2 = tk.Radiobutton(instance_frame, text="US", variable=instance_var, value="us001.accsense.com")
    rb2.pack(side=tk.LEFT)
    rb3 = tk.Radiobutton(instance_frame, text="Custom", variable=instance_var, value="custom")
    rb3.pack(side=tk.LEFT)
    custom_instance = tk.Entry(instance_frame, width=20)
    custom_instance.pack(side=tk.LEFT, padx=5)

    cred_frame = tk.LabelFrame(left_frame, text="Stored Accsense Credentials", padx=5, pady=5)
    cred_frame.grid(row=6, column=0, columnspan=2, sticky="ew", pady=5)

    accsense_credentials_listbox = tk.Listbox(cred_frame, height=3, width=80)
    accsense_credentials_listbox.grid(row=0, column=0, columnspan=3, padx=5, pady=5)

    save_cred_btn = tk.Button(cred_frame, text="Save Credential", command=save_current_accsense_credential)
    save_cred_btn.grid(row=1, column=0, padx=5, pady=2)

    load_cred_btn = tk.Button(cred_frame, text="Load Credential", command=load_selected_accsense_credential)
    load_cred_btn.grid(row=1, column=1, padx=5, pady=2)

    del_cred_btn = tk.Button(cred_frame, text="Delete Credential", command=delete_selected_accsense_credential)
    del_cred_btn.grid(row=1, column=2, padx=5, pady=2)

    # RIGHT FRAME (Authentication and Token Management)
    right_frame = tk.Frame(top_container, padx=10, pady=10)
    right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

    auth_btn = tk.Button(
        right_frame, text="Authenticate & Get Tokens",
        command=lambda: run_threaded(authenticate_accsense),
        bg="#4caf50",
        fg="white",
        padx=10,
        pady=5
    )
    auth_btn.pack(pady=10)

    token_frame = tk.LabelFrame(right_frame, text="Authentication Results", padx=10, pady=10)
    token_frame.pack(fill=tk.X, padx=10)

    accsense_access_token_entry = tk.Entry(token_frame, width=80)
    tk.Label(token_frame, text="Access Token:").grid(row=0, column=0, sticky="w", pady=5)
    accsense_access_token_entry.grid(row=0, column=1, padx=5, pady=5)
    copy_acc_btn = tk.Button(
        token_frame, text="Copy",
        command=lambda: root.clipboard_append(accsense_access_token_entry.get())
    )
    copy_acc_btn.grid(row=0, column=2, padx=5, pady=5)

    accsense_bearer_token_entry = tk.Entry(token_frame, width=80)
    tk.Label(token_frame, text="Bearer Token (ID):").grid(row=1, column=0, sticky="w", pady=5)
    accsense_bearer_token_entry.grid(row=1, column=1, padx=5, pady=5)
    copy_bearer_btn = tk.Button(
        token_frame, text="Copy",
        command=lambda: root.clipboard_append(accsense_bearer_token_entry.get())
    )
    copy_bearer_btn.grid(row=1, column=2, padx=5, pady=5)

    tm_frame = create_token_management_frame(token_frame, root)
    tm_frame.grid(row=2, column=0, columnspan=3, pady=10, sticky="ew")

    # Now place the Tenant selection and the main Notebook below
    tenant_dropdown_frame = tk.Frame(parent, padx=10, pady=5)
    tenant_dropdown_frame.pack(fill=tk.X)
    tk.Label(tenant_dropdown_frame, text="Select Tenant:").pack(side=tk.LEFT)
    tenant_dropdown_var = tk.StringVar(value="-- Choose a Tenant --")
    tenant_dropdown = tk.OptionMenu(tenant_dropdown_frame, tenant_dropdown_var, "-- No Tenants Loaded --")
    tenant_dropdown.config(width=30)
    tenant_dropdown.pack(side=tk.LEFT, padx=5)

    btn_tenant_info = tk.Button(
        tenant_dropdown_frame, text="Get Tenant Info",
        command=lambda: run_threaded(get_tenant_info),
        bg="#2196f3", fg="white"
    )
    btn_tenant_info.pack(side=tk.LEFT, padx=5)

    btn_customers = tk.Button(
        tenant_dropdown_frame, text="Get Customers",
        command=lambda: run_threaded(get_customers),
        bg="#2196f3", fg="white"
    )
    btn_customers.pack(side=tk.LEFT, padx=5)

    # Notebook for multiple tabs
    accsense_notebook = ttk.Notebook(accsense_api_tab)
    accsense_notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    # Console Tab
    console_tab = tk.Frame(accsense_notebook, padx=10, pady=10)
    accsense_notebook.add(console_tab, text="Console")

    accsense_console_text = tk.Text(console_tab, height=15, state='disabled')
    accsense_console_text.pack(fill=tk.BOTH, expand=True)
    clear_console_btn = tk.Button(console_tab, text="Clear Console",
                                  command=lambda: clear_console(accsense_console_text))
    clear_console_btn.pack(pady=5)

    # Endpoints Tab
    endpoints_tab = create_endpoints_tab(accsense_notebook)
    accsense_notebook.add(endpoints_tab, text="Endpoints")

    # Data Collection Tab
    datacollect_tab = tk.Frame(accsense_notebook, padx=10, pady=10)
    accsense_notebook.add(datacollect_tab, text="Data Collection")

    collect_frame = tk.Frame(datacollect_tab)
    collect_frame.pack(fill=tk.X, pady=10)

    tk.Label(collect_frame, text="Collection Type:").grid(row=0, column=0, sticky="w", pady=5)
    collection_type = tk.StringVar(value="users")
    tk.Radiobutton(collect_frame, text="Users", variable=collection_type, value="users").grid(row=0, column=1, sticky="w")
    tk.Radiobutton(collect_frame, text="Groups", variable=collection_type, value="groups").grid(row=0, column=2, sticky="w")
    tk.Radiobutton(collect_frame, text="Applications", variable=collection_type, value="apps").grid(row=0, column=3, sticky="w")

    collect_btn = tk.Button(
        collect_frame,
        text="Collect Data",
        command=lambda: run_threaded(lambda: collect_data(
            instance_var.get() if instance_var.get() != "custom" else custom_instance.get(),
            accsense_access_token_entry.get(),
            collection_type.get()
        ))
    )
    collect_btn.grid(row=1, column=0, columnspan=4, pady=10)

    collect_results = tk.Text(datacollect_tab, height=15)
    collect_results.pack(fill=tk.BOTH, expand=True)

    # Tenant Info Tab
    tenant_info_tab = tk.Frame(accsense_notebook, padx=10, pady=10)
    accsense_notebook.add(tenant_info_tab, text="Tenant Info")
    global tenant_info_text
    tenant_info_text = tk.Text(tenant_info_tab, height=15, state='disabled')
    tenant_info_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # Customers Tab
    customers_tab = tk.Frame(accsense_notebook, padx=10, pady=10)
    accsense_notebook.add(customers_tab, text="Customers")
    global customers_text
    customers_text = tk.Text(customers_tab, height=15, state='disabled')
    customers_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # User Management Tab
    user_mgmt_tab = create_user_management_tab(accsense_notebook)
    accsense_notebook.add(user_mgmt_tab, text="User Management")

    # API Logs Tab
    logs_tab = create_api_logs_tab(accsense_notebook)
    accsense_notebook.add(logs_tab, text="API Logs")

    action_buttons.extend([
        save_cred_btn, load_cred_btn, del_cred_btn, auth_btn, copy_acc_btn,
        copy_bearer_btn, collect_btn, clear_console_btn
    ])

    # Load credentials from file
    try:
        load_accsense_credentials_from_file()
        update_accsense_credentials_listbox()
    except Exception as e:
        log_console_ref(f"Error init Accsense => {str(e)}")

    return accsense_api_tab

################################################################################
# STANDALONE MAIN (for quick testing)
################################################################################

def main():
    def run_threaded(func):
        # For demonstration, just run on main thread here.
        func()

    def update_progress_start(msg):
        print("[Start]", msg)

    def update_progress_complete(msg):
        print("[Complete]", msg)

    def log_console(msg):
        print("[Log]", msg)
        local_log(msg)

    def validate_okta_url(url):
        return url.startswith("http://") or url.startswith("https://")

    def normalize_url(url):
        return url.rstrip('/')

    action_buttons = []
    root = tk.Tk()
    root.title("Accsense Tab Standalone Example")

    main_tab = create_accsense_api_tab(
        root,
        root,
        action_buttons,
        log_console,
        run_threaded,
        update_progress_start,
        update_progress_complete,
        validate_okta_url,
        normalize_url
    )
    main_tab.pack(fill=tk.BOTH, expand=True)

    root.mainloop()

if __name__ == "__main__":
    main()
