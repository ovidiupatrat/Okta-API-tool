import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
from ttkthemes import ThemedTk
from datetime import datetime
import requests
import random
import time
import threading
import queue
import csv
import json
import os
import sqlite3
from collections import defaultdict
from urllib.parse import urlparse, urljoin
import urllib.robotparser
from difflib import SequenceMatcher
from requests_html import HTMLSession  # For JS rendering

# ------------------ Suppress XMLParsedAsHTMLWarning --------------------
from bs4 import XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

# Optional libraries:
try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False

try:
    from lxml import etree
    LXML_AVAILABLE = True
except ImportError:
    LXML_AVAILABLE = False

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

# Force BeautifulSoup as available for this example.
BS4_AVAILABLE = True

###############################################################################
# JavaScript rendering for x.com
###############################################################################
def fetch_x_com(url, logger_func, user_agents):
    try:
        session = HTMLSession()
        session.headers.update({"User-Agent": random.choice(user_agents)})
        resp = session.get(url)
        resp.html.render(timeout=30, wait=2)
        return resp.html.html
    except Exception as e:
        logger_func(f"JS render error (x.com): {e}", "ERROR")
        return ""

###############################################################################
# Plugin Framework
###############################################################################
class BaseParserPlugin:
    def parse(self, html_content, url):
        raise NotImplementedError

class PluginManager:
    def __init__(self):
        self.plugins = {}

    def add_plugin_config(self, domain, module_path):
        self.plugins[domain.lower()] = [module_path, None]

    def get_parser_for_domain(self, domain):
        domain = domain.lower()
        if domain not in self.plugins:
            return None
        mod_path, instance = self.plugins[domain]
        if instance is not None:
            return instance
        try:
            import importlib
            mod = importlib.import_module(mod_path)
            if hasattr(mod, "Parser"):
                cls = getattr(mod, "Parser")
                if not issubclass(cls, BaseParserPlugin):
                    print(f"Plugin for domain '{domain}' is not a subclass of BaseParserPlugin.")
                    return None
                instance = cls()
                self.plugins[domain][1] = instance
                return instance
            else:
                print(f"Module {mod_path} does not have a Parser class.")
                return None
        except Exception as e:
            print(f"Plugin load error for domain '{domain}': {e}")
            return None

###############################################################################
# ScraperConfig
###############################################################################
class ScraperConfig:
    def __init__(self):
        # BFS / crawler scope
        self.max_depth = 2
        self.scope_type = "domain_only"  # Options: "no_restriction", "domain_only", "subpath_only"
        self.delay = 1.0
        self.ignore_robots = True

        # Authentication attributes (explicitly defined)
        self.login_url = ""
        self.username = ""
        self.password = ""
        self.api_token = ""

        # Relevance filter
        self.keywords = []
        self.relevance_threshold = 1

        # Default custom selectors
        self.custom_selectors = {
    "price": {"type": "css", "selector": 'span[itemprop="price"], .price, .product-price, [class*="price"]'},
    "title": {"type": "css", "selector": 'h1, title, .product-title, .entry-title'},
    "meta_description": {"type": "css", "selector": 'meta[name="description"]::attr(content)'},
    "canonical": {"type": "css", "selector": 'link[rel="canonical"]::attr(href)'},
    "author": {"type": "css", "selector": 'meta[name="author"]::attr(content), .author, .byline'},
    "publish_date": {"type": "css", "selector": 'meta[property="article:published_time"]::attr(content), time[datetime]::attr(datetime), .publish-date'},
    "images": {"type": "css", "selector": 'img.primary, img.featured, .main-image, .product-image'},
    "og_title": {"type": "css", "selector": 'meta[property="og:title"]::attr(content)'},
    "og_description": {"type": "css", "selector": 'meta[property="og:description"]::attr(content)'},
    "og_image": {"type": "css", "selector": 'meta[property="og:image"]::attr(content)'},
    "article_body": {"type": "css", "selector": 'article, .article-content, .post-content, .entry-content'},
    "meta_keywords": {"type": "css", "selector": 'meta[name="keywords"]::attr(content)'},
    "robots_meta": {"type": "css", "selector": 'meta[name="robots"]::attr(content)'},
    "language": {"type": "css", "selector": 'html::attr(lang)'},
    "favicon": {"type": "css", "selector": 'link[rel~="icon"]::attr(href)'},
    "original_price": {"type": "css", "selector": 'p.pricing del, p.pricing .old-price, .price-old, .original-price'},
    "product_availability": {"type": "css", "selector": '.availability-status, .stock-status, p.stock-and-genius, .in-stock, .out-of-stock'},
    "rating_value": {"type": "css", "selector": 'meta[itemprop="ratingValue"]::attr(content), span.rating-value, .average-rating'},
    "reviews_count": {"type": "css", "selector": 'meta[itemprop="reviewCount"]::attr(content), span.reviews-count, .total-reviews'},
    "subtitle": {"type": "css", "selector": 'h2.subtitle, .article-subtitle'},
    "author_profile_link": {"type": "css", "selector": 'a.author-link::attr(href), .author a::attr(href)'},
    "tags": {"type": "css", "selector": 'meta[name="news_keywords"]::attr(content), .tags a, .tag-list a'},
    "category": {"type": "css", "selector": 'meta[property="article:published_section"]::attr(content), .breadcrumb a:last-child'},
    "reading_time": {"type": "css", "selector": '.reading-time, span.read-time'},
    "twitter_title": {"type": "css", "selector": 'meta[name="twitter:title"]::attr(content)'},
    "twitter_description": {"type": "css", "selector": 'meta[name="twitter:description"]::attr(content)'},
    "twitter_image": {"type": "css", "selector": 'meta[name="twitter:image"]::attr(content)'},
    "facebook_app_id": {"type": "css", "selector": 'meta[property="fb:app_id"]::attr(content)'},
    "breadcrumbs": {"type": "css", "selector": 'nav.breadcrumb, ol.breadcrumb, .breadcrumbs'},
    "related_articles": {"type": "css", "selector": '.related-articles a::attr(href), .recommended-posts a::attr(href)'},
    "comments_count": {"type": "css", "selector": 'span.comments-count, .comment-count'},
    # Social Media Profiles
    "twitter_profile": {"type": "css", "selector": 'a[href*="twitter.com"]::attr(href)'},
    "linkedin_profile": {"type": "css", "selector": 'a[href*="linkedin.com"]::attr(href)'},
    "facebook_profile": {"type": "css", "selector": 'a[href*="facebook.com"]::attr(href)'},

    # Video Content
    "video_embed": {"type": "css", "selector": 'iframe[src*="youtube.com"], iframe[src*="vimeo.com"]::attr(src)'},

    # Product Information (E-commerce)
    "sku": {"type": "css", "selector": '.sku, span[itemprop="sku"], [class*="product-sku"]'},
    "brand": {"type": "css", "selector": '.brand, [itemprop="brand"], [class*="product-brand"]'},
    "product_description": {"type": "css", "selector": '#product-description, .description, [itemprop="description"]'},
    "discount": {"type": "css", "selector": '.discount, .badge-discount, .sale-badge'},

    # SEO Meta
    "meta_title": {"type": "css", "selector": 'meta[name="title"]::attr(content)'},
    "meta_author": {"type": "css", "selector": 'meta[name="author"]::attr(content)'},
    "meta_publisher": {"type": "css", "selector": 'meta[name="publisher"]::attr(content)'},
    "meta_language": {"type": "css", "selector": 'meta[http-equiv="content-language"]::attr(content)'},

    # Structured Data
    "json_ld": {"type": "css", "selector": 'script[type="application/ld+json"]'},

    # Article Additional Information
    "article_section": {"type": "css", "selector": 'meta[property="article:section"]::attr(content)'},
    "article_tags": {"type": "css", "selector": 'meta[property="article:tag"]::attr(content)'},

    # Navigation and Footer
    "footer_links": {"type": "css", "selector": 'footer a::attr(href)'},

    # Date Modified
    "modified_date": {"type": "css", "selector": 'meta[property="article:modified_time"]::attr(content), time.updated::attr(datetime)'},

    # Pagination
    "next_page": {"type": "css", "selector": 'link[rel="next"]::attr(href), a[rel="next"]::attr(href), .next-page a::attr(href)'},

    # Contact Information
    "email": {"type": "css", "selector": 'a[href^="mailto:"]::attr(href)'},
    "phone": {"type": "css", "selector": 'a[href^="tel:"]::attr(href), .phone-number, .tel'},

    # Location Information
    "address": {"type": "css", "selector": '[itemprop="address"], .address, .contact-address'},
    "city": {"type": "css", "selector": '[itemprop="addressLocality"], .city'},
    "country": {"type": "css", "selector": '[itemprop="addressCountry"], .country'},
    "postal_code": {"type": "css", "selector": '[itemprop="postalCode"], .postal-code, .zip-code'},

    # Site-Specific Scripts and Assets
    "analytics_id": {"type": "css", "selector": 'script[src*="analytics.js"], script[src*="gtag.js"]::attr(src)'},

    # Media Assets
    "pdf_links": {"type": "css", "selector": 'a[href$=".pdf"]::attr(href)'},
    "document_links": {"type": "css", "selector": 'a[href$=".doc"], a[href$=".docx"]::attr(href)'},

    # Promotional Information
    "coupon_code": {"type": "css", "selector": '.coupon-code, .promo-code'},
    "offer_expiration": {"type": "css", "selector": 'meta[itemprop="priceValidUntil"]::attr(content), .offer-end-date'},

    # Event Information
    "event_start_date": {"type": "css", "selector": '[itemprop="startDate"]::attr(content)'},
    "event_end_date": {"type": "css", "selector": '[itemprop="endDate"]::attr(content)'},
    "event_location": {"type": "css", "selector": '[itemprop="location"], .event-location'},

    # Reviews (e-commerce)
    "top_review": {"type": "css", "selector": '.review:first-of-type .review-text, .customer-review:first-of-type'},

    # Breadcrumb (detailed)
    "breadcrumbs_full": {"type": "css", "selector": 'nav.breadcrumb a::attr(href), ol.breadcrumb a::attr(href)'},

    # Additional metadata
    "viewport": {"type": "css", "selector": 'meta[name="viewport"]::attr(content)'},
    "charset": {"type": "css", "selector": 'meta[charset]::attr(charset)'}

}

        self.plugins = {}

        # Anti-blocking
        self.proxies = []
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Firefox/94.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
            "(KHTML, like Gecko) Version/15.1 Safari/605.1.15"
        ]

        # Export settings
        self.export_format = "csv"
        self.export_fields = []
        self.fuzzy_dedup = True
        self.follow_pagination = False

        # Autosave settings
        self.autosave_enabled = True
        self.autosave_interval = 300
        self.autosave_path = "autosave.csv"

        # Memory management
        self.aggregator_flush_size = 100

        # Stop conditions
        self.max_pages = 1000   # default
        self.max_runtime = 3600  # default: 1 hour

###############################################################################
# WebScraper
###############################################################################
class WebScraper:
    def __init__(self, config: ScraperConfig, plugin_manager: PluginManager, logger_func=None):
        self.config = config
        self.plugin_manager = plugin_manager
        self.logger = logger_func or print
        self.session = requests.Session()
        # Initialize aggregator-related attributes for concurrency
        self.request_count = 0
        self.aggregator = defaultdict(lambda: defaultdict(list))
        self.aggregator_lock = threading.Lock()
        self.last_autosave = time.time()

    def _make_request_with_retries(self, method, url, **kwargs):
        max_retries = 3
        delay = 1
        for attempt in range(max_retries):
            try:
                response = self.session.request(method, url, timeout=10, **kwargs)
                response.raise_for_status()
                return response
            except requests.HTTPError as he:
                self.logger(f"HTTP error for {url} (attempt {attempt+1}): {he}", "ERROR")
            except requests.ConnectionError as ce:
                self.logger(f"Connection error for {url} (attempt {attempt+1}): {ce}", "ERROR")
            except requests.Timeout as te:
                self.logger(f"Timeout for {url} (attempt {attempt+1}): {te}", "ERROR")
            except Exception as ex:
                self.logger(f"Unexpected error for {url} (attempt {attempt+1}): {ex}", "ERROR")
            if attempt < max_retries - 1:
                time.sleep(delay)
                delay *= 2
        return None

    def authenticate(self):
        # Use token if available
        if self.config.api_token:
            self.session.headers.update({"Authorization": f"Bearer {self.config.api_token}"})
        # Otherwise, attempt username/password login
        if self.config.login_url and self.config.username and self.config.password:
            self.logger("Attempting login...", "INFO")
            try:
                resp = self._make_request_with_retries(
                    "POST", self.config.login_url,
                    data={"username": self.config.username, "password": self.config.password}
                )
                if resp:
                    self.logger("Login successful.", "INFO")
                else:
                    self.logger("Login failed after retries.", "ERROR")
                    messagebox.showerror("Login Error", "Login failed after retries.")
            except Exception as e:
                self.logger(f"Login exception: {e}", "ERROR")
                messagebox.showerror("Login Error", f"Login exception: {e}")

    def is_allowed_by_robots(self, url):
        if self.config.ignore_robots:
            return True
        parsed = urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        rp = urllib.robotparser.RobotFileParser()
        rp.set_url(robots_url)
        try:
            time.sleep(self.config.delay)
            resp = self.session.get(robots_url, timeout=10)
            if resp.status_code == 200:
                rp.parse(resp.text.splitlines())
        except Exception as e:
            self.logger(f"robots.txt fetch error at {robots_url}: {e}", "WARNING")
            return True
        ua = random.choice(self.config.user_agents) if self.config.user_agents else "ScraperBot"
        can_fetch = rp.can_fetch(ua, url)
        if not can_fetch:
            messagebox.showwarning("Warning", "Robots.txt disallows crawling this page!")
        return can_fetch

    def in_scope(self, new_url, start_url):
        try:
            if self.config.scope_type == "no_restriction":
                return True
            parsed_new = urlparse(new_url)
            parsed_start = urlparse(start_url)
            if parsed_new.scheme not in ("http", "https"):
                return False
            if self.config.scope_type == "domain_only":
                return parsed_new.netloc.lower() == parsed_start.netloc.lower()
            if self.config.scope_type == "subpath_only":
                if parsed_new.netloc.lower() != parsed_start.netloc.lower():
                    return False
                sp = parsed_start.path or "/"
                np = parsed_new.path or "/"
                if not sp.endswith("/"):
                    sp += "/"
                return np.startswith(sp)
        except Exception as e:
            self.logger(f"Scope check error for {new_url}: {e}", "ERROR")
        return False

    def fetch_page(self, url):
        parsed = urlparse(url)
        try:
            if parsed.netloc.lower() == "x.com":
                self.logger("Using JS rendering for x.com", "INFO")
                return fetch_x_com(url, self.logger, self.config.user_agents)
            if not self.is_allowed_by_robots(url):
                self.logger(f"Blocked by robots.txt: {url}", "WARNING")
                return None

            self.request_count += 1
            if self.config.user_agents:
                self.session.headers.update({"User-Agent": random.choice(self.config.user_agents)})

            proxy = None
            if self.config.proxies:
                idx = self.request_count % len(self.config.proxies)
                proxy = {"http": self.config.proxies[idx], "https": self.config.proxies[idx]}

            time.sleep(self.config.delay)
            resp = self._make_request_with_retries("GET", url, proxies=proxy)
            if resp:
                return resp.text
            else:
                self.logger(f"Failed to fetch {url} after retries.", "ERROR")
                return None
        except Exception as e:
            self.logger(f"Exception fetching {url}: {e}", "ERROR")
            return None

    def is_relevant(self, html_text):
        try:
            if not self.config.keywords:
                return True
            txt_lower = html_text.lower()
            count = sum(1 for kw in self.config.keywords if kw.lower() in txt_lower)
            return count >= self.config.relevance_threshold
        except Exception as e:
            self.logger(f"Error in relevance check: {e}", "ERROR")
            return False

    def parse_page(self, url, html_content):
        dom = urlparse(url).netloc.lower()
        parsed_data = {}
        plugin = self.plugin_manager.get_parser_for_domain(dom)
        if plugin:
            try:
                parsed_data = plugin.parse(html_content, url)
            except Exception as e:
                self.logger(f"Plugin parse error for {dom}: {e}", "ERROR")
        # Default extraction
        default_data = self._default_extraction(html_content)
        for k, v in default_data.items():
            if k not in parsed_data:
                parsed_data[k] = v
        # Custom selectors extraction
        custom_data = self._custom_selectors(html_content)
        for k, v in custom_data.items():
            parsed_data[k] = v

        # Add parsed data to aggregator with robust locking and exception handling
        try:
            with self.aggregator_lock:
                for field_name, val in parsed_data.items():
                    if val is None:
                        continue
                    val_str = str(val).strip()
                    if val_str:
                        self.aggregator[url][field_name].append(val_str)
                # Check if flush is needed
                if len(self.aggregator) >= self.config.aggregator_flush_size:
                    self.logger("Aggregator flush threshold reached. Flushing data to disk...", "INFO")
                    flush_filename = f"aggregator_flush_{int(time.time())}.csv"
                    aggregator_copy = dict(self.aggregator)
                    self.aggregator.clear()

                    def flush_data_copy():
                        try:
                            with self.aggregator_lock:
                                data_list = self._convert_aggregator_to_list(aggregator_copy)
                            self.export_data_to_path(data_list, flush_filename)
                            self.logger(f"Flushed aggregator to {flush_filename}", "INFO")
                        except Exception as fe:
                            self.logger(f"Error during aggregator flush: {fe}", "ERROR")
                    threading.Thread(target=flush_data_copy, daemon=True).start()
        except Exception as e:
            self.logger(f"Error aggregating data from {url}: {e}", "ERROR")

    def _default_extraction(self, html_content):
        results = {}
        if not BS4_AVAILABLE:
            return results
        try:
            soup = BeautifulSoup(html_content, "lxml")
            if soup.title and soup.title.string:
                results["title"] = soup.title.string.strip()
            desc = soup.find("meta", attrs={"name": "description"})
            if desc and desc.get("content"):
                results["meta_description"] = desc["content"].strip()
        except Exception as e:
            self.logger(f"Default extraction error: {e}", "ERROR")
        return results

    def _custom_selectors(self, html_content):
        data = {}
        if not BS4_AVAILABLE:
            return data
        try:
            soup = BeautifulSoup(html_content, "lxml")
            for key, rule in self.config.custom_selectors.items():
                stype = rule.get("type", "css")
                selectors = rule.get("selector", "").split(",")
                val = None
                for sel in selectors:
                    sel = sel.strip()
                    try:
                        if stype == "css":
                            if "::attr" in sel:
                                css, attr_expr = sel.split("::attr", 1)
                                css, attr_name = css.strip(), attr_expr.strip(" ()")
                                el = soup.select_one(css)
                                if el and el.has_attr(attr_name):
                                    val = el[attr_name].strip()
                                    break
                            else:
                                el = soup.select_one(sel)
                                if el:
                                    val = el.get_text(strip=True)
                                    break
                        elif stype == "xpath" and LXML_AVAILABLE:
                            parser = etree.HTMLParser()
                            tree = etree.fromstring(html_content.encode("utf-8"), parser)
                            result = tree.xpath(sel)
                            if result:
                                if isinstance(result[0], str):
                                    val = result[0].strip()
                                elif hasattr(result[0], "text"):
                                    val = (result[0].text or "").strip()
                                else:
                                    val = str(result[0]).strip()
                                break
                    except Exception as ex:
                        self.logger(f"Custom selector error '{key}' -> '{sel}': {ex}", "ERROR")
                        continue
                if val:
                    data[key] = val
        except Exception as e:
            self.logger(f"Error applying custom selectors: {e}", "ERROR")
        return data

    def _convert_aggregator_to_list(self, aggregator_dict):
        results = []
        try:
            for url, fieldmap in aggregator_dict.items():
                row = {"url": url}
                for fname, vals in fieldmap.items():
                    if not self.config.fuzzy_dedup:
                        unique_vals = list(dict.fromkeys([v.strip() for v in vals if v.strip()]))
                        row[fname] = " | ".join(unique_vals)
                    else:
                        deduped = []
                        for cand in vals:
                            cand = cand.strip()
                            if not cand:
                                continue
                            if any(SequenceMatcher(None, cand, a).ratio() >= 0.85 for a in deduped):
                                continue
                            deduped.append(cand)
                        row[fname] = " | ".join(deduped)
                results.append(row)
        except Exception as e:
            self.logger(f"Error converting aggregator to list: {e}", "ERROR")
        return results

    def export_data_to_path(self, data_list, file_path):
        if not data_list:
            self.logger("No data to export.", "WARNING")
            return
        ext = os.path.splitext(file_path)[1].lower()
        mapping = {".csv": "csv", ".json": "json", ".xls": "excel", ".xlsx": "excel", ".db": "sqlite", ".sqlite": "sqlite"}
        fmt = mapping.get(ext, self.config.export_format.lower())
        if ext not in mapping:
            file_path += f".{fmt}"
        try:
            if fmt == "csv":
                fields = self.config.export_fields if self.config.export_fields else sorted(data_list[0].keys())
                with open(file_path, "w", newline="", encoding="utf-8") as f:
                    writer = csv.DictWriter(f, fieldnames=fields)
                    writer.writeheader()
                    for row in data_list:
                        filtered = {k: row.get(k, "") for k in fields}
                        writer.writerow(filtered)
                self.logger(f"Exported CSV => {file_path}", "INFO")
            elif fmt == "json":
                fields = self.config.export_fields
                filtered_data = [{k: row.get(k, "") for k in fields} for row in data_list] if fields else data_list
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(filtered_data, f, ensure_ascii=False, indent=2)
                self.logger(f"Exported JSON => {file_path}", "INFO")
            elif fmt == "excel":
                if not PANDAS_AVAILABLE:
                    self.logger("Pandas not installed. Cannot export to Excel.", "ERROR")
                    return
                fields = self.config.export_fields if self.config.export_fields else sorted(data_list[0].keys())
                df = pd.DataFrame(data_list)
                if fields:
                    df = df[fields]
                df.to_excel(file_path, index=False)
                self.logger(f"Exported Excel => {file_path}", "INFO")
            elif fmt == "sqlite":
                fields = self.config.export_fields if self.config.export_fields else sorted(data_list[0].keys())
                conn = sqlite3.connect(file_path)
                cur = conn.cursor()
                cols_def = ",".join([f"{c} TEXT" for c in fields])
                cur.execute(f"CREATE TABLE IF NOT EXISTS scraped_data ({cols_def});")
                for row in data_list:
                    vals = [str(row.get(c, "")) for c in fields]
                    placeholders = ",".join(["?"] * len(fields))
                    cur.execute(f"INSERT INTO scraped_data VALUES ({placeholders})", vals)
                conn.commit()
                conn.close()
                self.logger(f"Exported SQLite => {file_path}", "INFO")
            else:
                self.logger(f"Unsupported export format: {fmt}", "ERROR")
        except Exception as e:
            self.logger(f"Error exporting {fmt.upper()}: {e}", "ERROR")

    def export_data(self, file_path):
        with self.aggregator_lock:
            data_list = self._convert_aggregator_to_list(self.aggregator)
        self.export_data_to_path(data_list, file_path)

    def autosave_if_needed(self):
        try:
            if not self.config.autosave_enabled:
                return
            current_time = time.time()
            if current_time - self.last_autosave >= self.config.autosave_interval:
                t = threading.Thread(target=self.export_data, args=(self.config.autosave_path,), daemon=True)
                t.start()
                self.logger(f"Autosaved data to {self.config.autosave_path}", "INFO")
                self.last_autosave = current_time
        except Exception as e:
            self.logger(f"Autosave error: {e}", "ERROR")

###############################################################################
# CrawlerThread
###############################################################################
class CrawlerThread(threading.Thread):
    def __init__(self, scraper, start_url, stop_event, logger_func=None):
        super().__init__()
        self.scraper = scraper
        self.start_url = start_url
        self.stop_event = stop_event
        self.logger = logger_func or print
        self.link_queue = queue.Queue()
        self.visited = set()
        self.start_time = time.time()

    def run(self):
        self.link_queue.put((self.start_url, 0))
        while not self.stop_event.is_set():
            try:
                current_runtime = time.time() - self.start_time
                if current_runtime >= self.scraper.config.max_runtime:
                    self.logger(f"Max runtime ({self.scraper.config.max_runtime}s) reached; stopping crawl.", "WARNING")
                    self.stop_event.set()
                    break

                url, depth = self.link_queue.get(timeout=0.5)
            except queue.Empty:
                break
            except Exception as e:
                self.logger(f"Queue error: {e}", "ERROR")
                continue

            if url in self.visited or depth > self.scraper.config.max_depth:
                self.link_queue.task_done()
                continue

            self.visited.add(url)
            if len(self.visited) >= self.scraper.config.max_pages:
                self.logger(f"Maximum page limit ({self.scraper.config.max_pages}) reached; stopping crawl.", "WARNING")
                self.stop_event.set()
                break

            self.logger(f"Fetching (depth={depth}): {url}", "INFO")
            try:
                html = self.scraper.fetch_page(url)
                if html and self.scraper.is_relevant(html):
                    self.scraper.parse_page(url, html)
                    self.scraper.autosave_if_needed()
                    if BS4_AVAILABLE:
                        soup = BeautifulSoup(html, "lxml")
                        for a in soup.find_all("a", href=True):
                            nxt = urljoin(url, a["href"])
                            text = a.get_text(strip=True).lower()
                            # Handle pagination
                            if (self.scraper.config.follow_pagination and text in ("next", ">")):
                                if nxt not in self.visited and self.scraper.in_scope(nxt, self.start_url):
                                    self.link_queue.put((nxt, depth))
                            elif depth < self.scraper.config.max_depth and nxt not in self.visited and self.scraper.in_scope(nxt, self.start_url):
                                self.link_queue.put((nxt, depth + 1))
            except Exception as e:
                self.logger(f"Error during crawling {url}: {e}", "ERROR")
            finally:
                self.link_queue.task_done()
        self.logger("Crawl thread finished.", "INFO")

###############################################################################
# Scheduler
###############################################################################
class SchedulerJob:
    def __init__(self, config, plugin_manager, url, interval, export_path):
        self.config = config
        self.plugin_manager = plugin_manager
        self.url = url
        self.interval = interval
        self.export_path = export_path
        self.next_run = time.time() + interval
        self.crawler_thread = None
        self.export_thread = None
        self.stop_event = threading.Event()
        self.enabled = True

class ScraperScheduler:
    def __init__(self, logger_func):
        self.jobs = []
        self.logger = logger_func

    def schedule_job(self, config, plugin_manager, url, interval, export_path):
        job = SchedulerJob(config, plugin_manager, url, interval, export_path)
        self.jobs.append(job)
        self.logger(f"Scheduled: {url} every {interval}s => {export_path}", "INFO")
        return job

    def run_pending(self):
        now = time.time()
        for job in self.jobs:
            if not job.enabled:
                continue
            # Prevent overlapping runs by checking if threads are alive
            if (job.crawler_thread and job.crawler_thread.is_alive()) or (job.export_thread and job.export_thread.is_alive()):
                continue
            if now >= job.next_run:
                try:
                    sc = WebScraper(job.config, job.plugin_manager, logger_func=self.logger)
                    sc.authenticate()
                    job.stop_event = threading.Event()
                    ct = CrawlerThread(sc, job.url, job.stop_event, logger_func=self.logger)
                    job.crawler_thread = ct
                    ct.start()

                    def wait_and_export(job=job, scraper=sc):
                        try:
                            ct.join()
                        except Exception as e:
                            self.logger(f"Error joining crawl thread: {e}", "ERROR")
                        try:
                            scraper.export_data(job.export_path)
                        except Exception as e:
                            self.logger(f"Error exporting scheduled job data: {e}", "ERROR")
                        job.next_run = time.time() + job.interval
                    job.export_thread = threading.Thread(target=wait_and_export, daemon=True)
                    job.export_thread.start()
                except Exception as e:
                    self.logger(f"Scheduler error for job {job.url}: {e}", "ERROR")

###############################################################################
# ScrollableFrame for GUI
###############################################################################
class ScrollableFrame(tk.Frame):
    def __init__(self, container, *args, **kwargs):
        super().__init__(container, *args, **kwargs)
        self.canvas = tk.Canvas(self, borderwidth=0, background="gray20")
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, background="gray20")
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

###############################################################################
# ScraperGUI
###############################################################################
class ScraperGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Penus Scraper")
        self.root.geometry("1280x720")
        self.root.minsize(1024, 600)
        self.root.configure(bg="gray20")
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)

        self.config = ScraperConfig()
        self.plugin_manager = PluginManager()
        self.scheduler = ScraperScheduler(self.thread_safe_log)
        self.stop_event = threading.Event()
        self.crawler_thread = None
        self.scraper = None

        # Status bar setup
        status_frame = ttk.Frame(self.root)
        status_frame.pack(side="bottom", fill="x", padx=10, pady=10)
        self.status_var = tk.StringVar(value="Idle")
        self.status_label = ttk.Label(status_frame, textvariable=self.status_var)
        self.status_label.pack(side="left", padx=10)
        self.progress = ttk.Progressbar(status_frame, orient="horizontal", length=200, mode="determinate")
        self.progress.pack(side="right", padx=10)

        # Scrollable container
        self.scrollable = ScrollableFrame(self.root)
        self.scrollable.pack(fill="both", expand=True)
        self._build_ui(self.scrollable.scrollable_frame)
        self._check_scheduler()
        self._update_progress()

    def _build_ui(self, container):
        notebook = ttk.Notebook(container)
        notebook.pack(fill="both", expand=True, padx=20, pady=20)
        # Setup tab
        self.setup_frame = ttk.Frame(notebook)
        for i in range(2):
            self.setup_frame.grid_columnconfigure(i, weight=1)
        notebook.add(self.setup_frame, text="Setup")
        self._build_setup_tab(self.setup_frame)
        # Scheduler tab
        self.scheduler_frame = ttk.Frame(notebook)
        self.scheduler_frame.grid_columnconfigure(0, weight=1)
        notebook.add(self.scheduler_frame, text="Scheduler")
        self._build_scheduler_tab(self.scheduler_frame)
        # Log & Export tab
        self.log_frame = ttk.Frame(notebook)
        self.log_frame.grid_columnconfigure(0, weight=1)
        notebook.add(self.log_frame, text="Log & Export")
        self._build_log_tab(self.log_frame)

    def _build_setup_tab(self, frame):
        row = 0
        ttk.Label(frame, text="Start URL:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.start_url_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.start_url_var, width=60).grid(row=row, column=1, padx=15, pady=5, sticky="ew")
        self.setup_frame.grid_columnconfigure(1, weight=2)
        row += 1
        ttk.Label(frame, text="Max Depth:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.depth_var = tk.IntVar(value=2)
        ttk.Entry(frame, textvariable=self.depth_var, width=5).grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Scope:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.scope_var = tk.StringVar(value="domain_only")
        ttk.Combobox(frame, textvariable=self.scope_var,
                     values=["no_restriction", "domain_only", "subpath_only"],
                     width=15, state="readonly").grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Delay (s):").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.delay_var = tk.DoubleVar(value=1.0)
        ttk.Entry(frame, textvariable=self.delay_var, width=5).grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        self.ignore_robots_var = tk.BooleanVar(value=True)
        tk.Checkbutton(frame, text="Ignore robots.txt", variable=self.ignore_robots_var,
                       background="gray20", fg="white", selectcolor="gray30",
                       command=self.apply_config).grid(row=row, column=1, padx=15, pady=5, sticky="w")
        row += 1
        ttk.Label(frame, text="Login URL:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.login_url_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.login_url_var, width=60).grid(row=row, column=1, padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Username:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.username_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.username_var, width=30).grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Password:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.password_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.password_var, show="*", width=30).grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="API Token:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.token_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.token_var, width=60).grid(row=row, column=1, padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Keywords (comma):").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.keywords_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.keywords_var, width=60).grid(row=row, column=1, padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Relevance Threshold:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.threshold_var = tk.IntVar(value=1)
        ttk.Entry(frame, textvariable=self.threshold_var, width=5).grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Proxies (comma):").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.proxies_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.proxies_var, width=60).grid(row=row, column=1, padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="User-Agents (comma):").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.ua_var = tk.StringVar(value=", ".join(self.config.user_agents))
        ttk.Entry(frame, textvariable=self.ua_var, width=60).grid(row=row, column=1, padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Export Format:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.export_fmt_var = tk.StringVar(value="csv")
        ttk.Combobox(frame, textvariable=self.export_fmt_var,
                     values=["csv", "json", "excel", "sqlite"],
                     width=10, state="readonly").grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        self.fuzzy_var = tk.BooleanVar(value=True)
        tk.Checkbutton(frame, text="Fuzzy Deduplicate", variable=self.fuzzy_var,
                       background="gray20", fg="white", selectcolor="gray30",
                       command=self.apply_config).grid(row=row, column=1, padx=15, pady=5, sticky="w")
        row += 1
        self.pagination_var = tk.BooleanVar(value=False)
        tk.Checkbutton(frame, text="Enable Pagination Handling", variable=self.pagination_var,
                       background="gray20", fg="white", selectcolor="gray30",
                       command=self.apply_config).grid(row=row, column=1, padx=15, pady=5, sticky="w")
        row += 1
        ttk.Label(frame, text="Autosave Interval (s):").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.autosave_interval_var = tk.IntVar(value=300)
        ttk.Entry(frame, textvariable=self.autosave_interval_var, width=10).grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Autosave Path:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.autosave_path_var = tk.StringVar(value="autosave.csv")
        ttk.Entry(frame, textvariable=self.autosave_path_var, width=40).grid(row=row, column=1, padx=15, pady=5)
        row += 1
        self.autosave_enabled_var = tk.BooleanVar(value=True)
        tk.Checkbutton(frame, text="Enable Autosave", variable=self.autosave_enabled_var,
                       background="gray20", fg="white", selectcolor="gray30",
                       command=self.apply_config).grid(row=row, column=1, padx=15, pady=5, sticky="w")
        row += 1
        ttk.Label(frame, text="Max Pages:").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.max_pages_var = tk.IntVar(value=1000)
        ttk.Entry(frame, textvariable=self.max_pages_var, width=10).grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        ttk.Label(frame, text="Max Runtime (s):").grid(row=row, column=0, padx=15, pady=5, sticky="e")
        self.max_runtime_var = tk.IntVar(value=3600)
        ttk.Entry(frame, textvariable=self.max_runtime_var, width=10).grid(row=row, column=1, sticky="w", padx=15, pady=5)
        row += 1
        cs_frame = ttk.LabelFrame(frame, text="Custom Selectors")
        cs_frame.grid(row=row, column=0, columnspan=2, padx=15, pady=5, sticky="ew")
        cs_frame.columnconfigure(0, weight=1)
        row_cs = 0
        ttk.Label(cs_frame, text="Name:").grid(row=row_cs, column=0, padx=15, pady=5, sticky="e")
        self.cs_name_var = tk.StringVar()
        ttk.Entry(cs_frame, textvariable=self.cs_name_var, width=15).grid(row=row_cs, column=1, padx=15, pady=5)
        row_cs += 1
        ttk.Label(cs_frame, text="Type:").grid(row=row_cs, column=0, padx=15, pady=5, sticky="e")
        self.cs_type_var = tk.StringVar(value="css")
        ttk.Combobox(cs_frame, textvariable=self.cs_type_var, values=["css", "xpath"],
                     width=10, state="readonly").grid(row=row_cs, column=1, padx=15, pady=5)
        row_cs += 1
        ttk.Label(cs_frame, text="Selector:").grid(row=row_cs, column=0, padx=15, pady=5, sticky="e")
        self.cs_sel_var = tk.StringVar()
        ttk.Entry(cs_frame, textvariable=self.cs_sel_var, width=40).grid(row=row_cs, column=1, padx=15, pady=5)
        row_cs += 1
        self.selector_listbox = tk.Listbox(cs_frame, width=50, height=5, bg="gray30", fg="white")
        self.selector_listbox.grid(row=row_cs, column=0, columnspan=2, padx=15, pady=5)
        row_cs += 1
        ttk.Button(cs_frame, text="Add Selector", command=self.add_selector).grid(row=row_cs, column=0, padx=15, pady=5, sticky="w")
        ttk.Button(cs_frame, text="Remove Selector", command=self.remove_selector).grid(row=row_cs, column=1, padx=15, pady=5, sticky="e")
        row += 1
        plugin_frame = ttk.LabelFrame(frame, text="Plugins")
        plugin_frame.grid(row=row, column=0, columnspan=2, padx=15, pady=5, sticky="ew")
        plugin_frame.columnconfigure(0, weight=1)
        row_plug = 0
        ttk.Label(plugin_frame, text="Domain:").grid(row=row_plug, column=0, padx=15, pady=5, sticky="e")
        self.plugin_dom_var = tk.StringVar()
        ttk.Entry(plugin_frame, textvariable=self.plugin_dom_var, width=20).grid(row=row_plug, column=1, padx=15, pady=5)
        row_plug += 1
        ttk.Label(plugin_frame, text="Module Path:").grid(row=row_plug, column=0, padx=15, pady=5, sticky="e")
        self.plugin_path_var = tk.StringVar()
        ttk.Entry(plugin_frame, textvariable=self.plugin_path_var, width=40).grid(row=row_plug, column=1, padx=15, pady=5)
        row_plug += 1
        self.plugin_listbox = tk.Listbox(plugin_frame, width=60, height=3, bg="gray30", fg="white")
        self.plugin_listbox.grid(row=row_plug, column=0, columnspan=2, padx=15, pady=5)
        row_plug += 1
        ttk.Button(plugin_frame, text="Add Plugin", command=self.add_plugin).grid(row=row_plug, column=0, padx=15, pady=5, sticky="w")
        ttk.Button(plugin_frame, text="Remove Plugin", command=self.remove_plugin).grid(row=row_plug, column=1, padx=15, pady=5, sticky="e")
        row += 1
        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=row, column=0, columnspan=2, padx=15, pady=5, sticky="ew")
        btn_frame.columnconfigure(0, weight=1)
        ttk.Button(btn_frame, text="Save Config", command=self.save_config_to_file).grid(row=0, column=0, padx=15, pady=5, sticky="ew")
        ttk.Button(btn_frame, text="Load Config", command=self.load_config_from_file).grid(row=0, column=1, padx=15, pady=5, sticky="ew")
        row += 1
        btn_frame2 = ttk.Frame(frame)
        btn_frame2.grid(row=row, column=0, columnspan=2, padx=15, pady=5, sticky="ew")
        btn_frame2.columnconfigure((0,1,2), weight=1)
        ttk.Button(btn_frame2, text="Apply Config", command=self.apply_config).grid(row=0, column=0, padx=5, pady=10, sticky="ew")
        ttk.Button(btn_frame2, text="Start Crawl", command=self.start_crawl).grid(row=0, column=1, padx=5, pady=10, sticky="ew")
        ttk.Button(btn_frame2, text="Stop Crawl", command=self.stop_crawl).grid(row=0, column=2, padx=5, pady=10, sticky="ew")
        self.populate_default_selectors()

    def populate_default_selectors(self):
        self.selector_listbox.delete(0, tk.END)
        for key, rule in self.config.custom_selectors.items():
            stype = rule.get("type", "css")
            selector = rule.get("selector", "")
            self.selector_listbox.insert(tk.END, f"{key} [{stype}] => {selector}")

    def add_selector(self):
        nm = self.cs_name_var.get().strip()
        tp = self.cs_type_var.get().strip()
        sl = self.cs_sel_var.get().strip()
        if not nm or not tp or not sl:
            messagebox.showerror("Error", "Please fill out name, type, and selector.")
            return
        self.config.custom_selectors[nm] = {"type": tp, "selector": sl}
        self.selector_listbox.insert(tk.END, f"{nm} [{tp}] => {sl}")
        self.cs_name_var.set("")
        self.cs_sel_var.set("")

    def remove_selector(self):
        idx = self.selector_listbox.curselection()
        if not idx:
            return
        line = self.selector_listbox.get(idx)
        self.selector_listbox.delete(idx)
        name = line.split(" [")[0].strip()
        if name in self.config.custom_selectors:
            del self.config.custom_selectors[name]

    def add_plugin(self):
        dm = self.plugin_dom_var.get().strip()
        mp = self.plugin_path_var.get().strip()
        if not dm or not mp:
            messagebox.showerror("Error", "Please fill out domain and module path.")
            return
        self.plugin_manager.add_plugin_config(dm, mp)
        self.plugin_listbox.insert(tk.END, f"{dm} => {mp}")
        self.plugin_dom_var.set("")
        self.plugin_path_var.set("")

    def remove_plugin(self):
        idx = self.plugin_listbox.curselection()
        if not idx:
            return
        line = self.plugin_listbox.get(idx)
        self.plugin_listbox.delete(idx)
        dm = line.split(" => ")[0].strip().lower()
        if dm in self.plugin_manager.plugins:
            del self.plugin_manager.plugins[dm]

    def apply_config(self):
        try:
            max_pages_input = self.max_pages_var.get()
            if max_pages_input <= 0:
                raise ValueError("Max Pages must be > 0")
            self.config.max_pages = max_pages_input
        except Exception as e:
            messagebox.showerror("Invalid Input", f"Error in Max Pages: {e}")
            return

        try:
            max_runtime_input = self.max_runtime_var.get()
            if max_runtime_input <= 0:
                raise ValueError("Max Runtime must be > 0")
            self.config.max_runtime = max_runtime_input
        except Exception as e:
            messagebox.showerror("Invalid Input", f"Error in Max Runtime: {e}")
            return

        self.config.max_depth = self.depth_var.get()
        self.config.scope_type = self.scope_var.get()
        self.config.delay = self.delay_var.get()
        self.config.ignore_robots = self.ignore_robots_var.get()
        self.config.login_url = self.login_url_var.get().strip()
        self.config.username = self.username_var.get().strip()
        self.config.password = self.password_var.get().strip()
        self.config.api_token = self.token_var.get().strip()
        kw_str = self.keywords_var.get().strip()
        self.config.keywords = [k.strip() for k in kw_str.split(",") if k.strip()] if kw_str else []
        self.config.relevance_threshold = self.threshold_var.get()
        px_str = self.proxies_var.get().strip()
        self.config.proxies = [p.strip() for p in px_str.split(",") if p.strip()] if px_str else []
        ua_str = self.ua_var.get().strip()
        self.config.user_agents = [u.strip() for u in ua_str.split(",") if u.strip()] if ua_str else []
        self.config.export_format = self.export_fmt_var.get()
        self.config.fuzzy_dedup = self.fuzzy_var.get()
        self.config.follow_pagination = self.pagination_var.get()
        self.config.autosave_enabled = self.autosave_enabled_var.get()
        self.config.autosave_interval = self.autosave_interval_var.get()
        self.config.autosave_path = self.autosave_path_var.get()
        self.thread_safe_log("Configuration applied.", "INFO")
        self.status_var.set("Configuration Applied")

    def start_crawl(self):
        if self.crawler_thread and self.crawler_thread.is_alive():
            messagebox.showerror("Error", "Already crawling. Stop first.")
            return
        self.apply_config()
        url = self.start_url_var.get().strip()
        if not url:
            messagebox.showerror("Error", "No start URL provided.")
            return
        self.scraper = WebScraper(self.config, self.plugin_manager, logger_func=self.thread_safe_log)
        self.scraper.authenticate()
        self.stop_event.clear()
        self.crawler_thread = CrawlerThread(self.scraper, url, self.stop_event, logger_func=self.thread_safe_log)
        self.crawler_thread.start()
        self.thread_safe_log("Crawler started...", "INFO")
        self.status_var.set("Crawling...")

    def stop_crawl(self):
        if self.crawler_thread and self.crawler_thread.is_alive():
            self.stop_event.set()
            self.thread_safe_log("Stop event set. Waiting for crawl to end.", "INFO")
            self.status_var.set("Stopping Crawl...")
        else:
            self.thread_safe_log("No active crawl to stop.", "WARNING")
            self.status_var.set("Idle")

    def _build_scheduler_tab(self, frame):
        ttk.Label(frame, text="URL:").grid(row=0, column=0, padx=15, pady=5, sticky="e")
        self.sched_url_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.sched_url_var, width=50).grid(row=0, column=1, padx=15, pady=5)
        ttk.Label(frame, text="Interval (s):").grid(row=1, column=0, padx=15, pady=5, sticky="e")
        self.sched_interval_var = tk.IntVar(value=3600)
        ttk.Entry(frame, textvariable=self.sched_interval_var, width=10).grid(row=1, column=1, sticky="w", padx=15, pady=5)
        ttk.Label(frame, text="Export Path:").grid(row=2, column=0, padx=15, pady=5, sticky="e")
        self.sched_export_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.sched_export_var, width=50).grid(row=2, column=1, padx=15, pady=5)
        ttk.Button(frame, text="Browse...", command=self._browse_export).grid(row=2, column=2, padx=15, pady=5, sticky="w")
        ttk.Button(frame, text="Schedule", command=self._schedule_job).grid(row=3, column=1, padx=15, pady=5)
        self.scheduler_listbox = tk.Listbox(frame, width=80, height=8, bg="gray30", fg="white")
        self.scheduler_listbox.grid(row=4, column=0, columnspan=3, padx=15, pady=5)
        ttk.Button(frame, text="Toggle Selected Job", command=self.toggle_selected_job).grid(row=5, column=0, padx=15, pady=5, sticky="w")
        ttk.Button(frame, text="Save Scheduler Config", command=self.save_scheduler_config).grid(row=5, column=1, padx=15, pady=5)
        ttk.Button(frame, text="Load Scheduler Config", command=self.load_scheduler_config).grid(row=5, column=2, padx=15, pady=5)

    def _browse_export(self):
        p = filedialog.asksaveasfilename(title="Export Path", defaultextension="." + self.config.export_format)
        if p:
            self.sched_export_var.set(p)

    def _schedule_job(self):
        self.apply_config()
        url = self.sched_url_var.get().strip()
        if not url:
            messagebox.showerror("Error", "No URL for scheduling.")
            return
        itv = self.sched_interval_var.get()
        ep = self.sched_export_var.get().strip()
        if not ep:
            messagebox.showerror("Error", "No export path set.")
            return
        job = self.scheduler.schedule_job(self.config, self.plugin_manager, url, itv, ep)
        self.scheduler_listbox.insert(tk.END, f"Scheduled: {url} every {itv}s -> {ep} [Enabled]")
        self.thread_safe_log(f"Job scheduled for {url}", "INFO")

    def toggle_selected_job(self):
        idx = self.scheduler_listbox.curselection()
        if not idx:
            messagebox.showerror("Error", "No job selected.")
            return
        i = idx[0]
        job = self.scheduler.jobs[i]
        job.enabled = not job.enabled
        status = "Enabled" if job.enabled else "Disabled"
        self.scheduler_listbox.delete(i)
        self.scheduler_listbox.insert(i, f"Scheduled: {job.url} every {job.interval}s -> {job.export_path} [{status}]")
        self.thread_safe_log(f"Job for {job.url} {status}", "INFO")

    def save_scheduler_config(self):
        jobs_config = [
            {
                "url": job.url,
                "interval": job.interval,
                "export_path": job.export_path,
                "enabled": job.enabled
            } for job in self.scheduler.jobs
        ]
        try:
            with open("scheduler_config.json", "w") as f:
                json.dump(jobs_config, f, indent=4)
            self.thread_safe_log("Scheduler configuration saved.", "INFO")
        except Exception as e:
            self.thread_safe_log(f"Error saving scheduler config: {e}", "ERROR")

    def load_scheduler_config(self):
        try:
            with open("scheduler_config.json") as f:
                jobs_config = json.load(f)
            self.scheduler.jobs.clear()
            self.scheduler_listbox.delete(0, tk.END)
            for job_conf in jobs_config:
                job = self.scheduler.schedule_job(
                    self.config,
                    self.plugin_manager,
                    job_conf["url"],
                    job_conf["interval"],
                    job_conf["export_path"]
                )
                job.enabled = job_conf.get("enabled", True)
                status = "Enabled" if job.enabled else "Disabled"
                self.scheduler_listbox.insert(tk.END, f"Scheduled: {job.url} every {job.interval}s -> {job.export_path} [{status}]")
            self.thread_safe_log("Scheduler configuration loaded.", "INFO")
        except FileNotFoundError:
            self.thread_safe_log("No scheduler configuration file found.", "WARNING")
        except Exception as e:
            self.thread_safe_log(f"Error loading scheduler config: {e}", "ERROR")

    def _build_log_tab(self, frame):
        self.log_text = ScrolledText(frame, wrap=tk.WORD, height=15, bg="gray20", fg="white", insertbackground="white")
        self.log_text.pack(fill="both", expand=True, padx=15, pady=5)
        ttk.Button(frame, text="Save Now", command=self.save_now).pack(padx=15, pady=5)

    def save_now(self):
        if not self.scraper:
            self.thread_safe_log("No scraper instance available. Run a crawl first.", "WARNING")
            return
        if not self.scraper.aggregator:
            self.thread_safe_log("No data to save.", "WARNING")
            return
        p = filedialog.asksaveasfilename(title="Save Aggregated Data", defaultextension="." + self.config.export_format)
        if not p:
            return
        t = threading.Thread(target=self.scraper.export_data, args=(p,), daemon=True)
        t.start()

    def thread_safe_log(self, msg, level="INFO"):
        try:
            colors = {"INFO": "white", "WARNING": "orange", "ERROR": "red"}
            timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
            full_msg = f"{timestamp} {level}: {msg}"
            self.root.after(0, lambda: self._append_log(full_msg, colors.get(level, "white")))
        except Exception as e:
            print(f"Logging error: {e}")

    def _append_log(self, msg, color):
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.tag_config(color, foreground=color)
        self.log_text.see(tk.END)

    def save_config_to_file(self):
        try:
            config_dict = {
                "max_depth": self.config.max_depth,
                "scope_type": self.config.scope_type,
                "delay": self.config.delay,
                "ignore_robots": self.config.ignore_robots,
                "login_url": self.config.login_url,
                "username": self.config.username,
                "password": self.config.password,
                "api_token": self.config.api_token,
                "keywords": self.config.keywords,
                "relevance_threshold": self.config.relevance_threshold,
                "custom_selectors": self.config.custom_selectors,
                "plugins": self.config.plugins,
                "proxies": self.config.proxies,
                "user_agents": self.config.user_agents,
                "export_format": self.config.export_format,
                "export_fields": self.config.export_fields,
                "fuzzy_dedup": self.config.fuzzy_dedup,
                "follow_pagination": self.config.follow_pagination,
                "autosave_enabled": self.config.autosave_enabled,
                "autosave_interval": self.config.autosave_interval,
                "autosave_path": self.config.autosave_path,
                "aggregator_flush_size": self.config.aggregator_flush_size,
                "max_pages": self.config.max_pages,
                "max_runtime": self.config.max_runtime
            }
            with open("scraper_config.json", "w") as f:
                json.dump(config_dict, f, indent=4)
            self.thread_safe_log("Configuration saved to scraper_config.json", "INFO")
        except Exception as e:
            self.thread_safe_log(f"Error saving configuration: {e}", "ERROR")
            messagebox.showerror("Error", f"Error saving configuration: {e}")

    def load_config_from_file(self):
        try:
            with open("scraper_config.json") as f:
                config_dict = json.load(f)
            self.config.max_depth = config_dict.get("max_depth", 2)
            self.config.scope_type = config_dict.get("scope_type", "domain_only")
            self.config.delay = config_dict.get("delay", 1.0)
            self.config.ignore_robots = config_dict.get("ignore_robots", True)
            self.config.login_url = config_dict.get("login_url", "")
            self.config.username = config_dict.get("username", "")
            self.config.password = config_dict.get("password", "")
            self.config.api_token = config_dict.get("api_token", "")
            self.config.keywords = config_dict.get("keywords", [])
            self.config.relevance_threshold = config_dict.get("relevance_threshold", 1)
            self.config.custom_selectors = config_dict.get("custom_selectors", {})
            self.config.plugins = config_dict.get("plugins", {})
            self.config.proxies = config_dict.get("proxies", [])
            self.config.user_agents = config_dict.get("user_agents", [])
            self.config.export_format = config_dict.get("export_format", "csv")
            self.config.export_fields = config_dict.get("export_fields", [])
            self.config.fuzzy_dedup = config_dict.get("fuzzy_dedup", True)
            self.config.follow_pagination = config_dict.get("follow_pagination", False)
            self.config.autosave_enabled = config_dict.get("autosave_enabled", True)
            self.config.autosave_interval = config_dict.get("autosave_interval", 300)
            self.config.autosave_path = config_dict.get("autosave_path", "autosave.csv")
            self.config.aggregator_flush_size = config_dict.get("aggregator_flush_size", 100)
            self.config.max_pages = config_dict.get("max_pages", 1000)
            self.config.max_runtime = config_dict.get("max_runtime", 3600)
            self.apply_loaded_config_to_gui()
            self.thread_safe_log("Configuration loaded from scraper_config.json", "INFO")
        except FileNotFoundError:
            self.thread_safe_log("No configuration file found (scraper_config.json).", "WARNING")
        except Exception as e:
            self.thread_safe_log(f"Config load error: {e}", "ERROR")
            messagebox.showerror("Error", f"Config load error: {e}")

    def apply_loaded_config_to_gui(self):
        self.depth_var.set(self.config.max_depth)
        self.scope_var.set(self.config.scope_type)
        self.delay_var.set(self.config.delay)
        self.ignore_robots_var.set(self.config.ignore_robots)
        self.login_url_var.set(self.config.login_url)
        self.username_var.set(self.config.username)
        self.password_var.set(self.config.password)
        self.token_var.set(self.config.api_token)
        self.keywords_var.set(", ".join(self.config.keywords))
        self.threshold_var.set(self.config.relevance_threshold)
        self.proxies_var.set(", ".join(self.config.proxies))
        self.ua_var.set(", ".join(self.config.user_agents))
        self.export_fmt_var.set(self.config.export_format)
        self.fuzzy_var.set(self.config.fuzzy_dedup)
        self.pagination_var.set(self.config.follow_pagination)
        self.autosave_enabled_var.set(self.config.autosave_enabled)
        self.autosave_interval_var.set(self.config.autosave_interval)
        self.autosave_path_var.set(self.config.autosave_path)
        self.max_pages_var.set(self.config.max_pages)
        self.max_runtime_var.set(self.config.max_runtime)
        self.populate_default_selectors()

    def _check_scheduler(self):
        self.scheduler.run_pending()
        self.root.after(1000, self._check_scheduler)

    def _update_progress(self):
        if self.crawler_thread and self.crawler_thread.is_alive():
            current_pages = len(self.crawler_thread.visited)
            total_pages = self.config.max_pages
            pages_percent = (current_pages / total_pages) * 100 if total_pages > 0 else 0
            current_runtime = time.time() - self.crawler_thread.start_time
            total_runtime = float(self.config.max_runtime)
            runtime_percent = (current_runtime / total_runtime) * 100 if total_runtime > 0 else 0
            percent = max(pages_percent, runtime_percent)
            percent = min(100, percent)
            self.progress['value'] = percent
            self.status_var.set(f"Crawling... Pages: {current_pages}/{total_pages}, Time: {int(current_runtime)}/{int(total_runtime)}s")
        else:
            self.progress['value'] = 0
            self.status_var.set("Idle")
        self.root.after(1000, self._update_progress)

def main():
    root = ThemedTk(theme="equilux")
    style = ttk.Style(root)
    style.theme_use("equilux")
    style.configure(".", background="gray20", foreground="white")
    style.configure("TFrame", background="gray20", foreground="white")
    style.configure("TLabel", background="gray20", foreground="white")
    style.configure("TButton", background="gray20", foreground="white")
    style.configure("TCheckbutton", background="gray20", foreground="white")
    style.configure("TNotebook", background="gray20", foreground="white")
    style.configure("TNotebook.Tab", background="gray30", foreground="white")
    style.configure("TCombobox", fieldbackground="gray30", background="gray30", foreground="white")
    style.configure("TEntry", fieldbackground="gray30", foreground="white")
    style.configure("Horizontal.TProgressbar", background="green")
    root.configure(bg="gray20")
    app = ScraperGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
