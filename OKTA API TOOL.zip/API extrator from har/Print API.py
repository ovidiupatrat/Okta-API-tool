import json
import os

# Path to the folder containing HAR files
folder_path = r"c:\Users\Ovidiu.M\Desktop\API extrator from har\har files"
api_requests = []
seen_requests = set()

# List all .har files in the folder
for file_name in os.listdir(folder_path):
    if file_name.endswith('.har'):
        # Load the HAR file
        with open(os.path.join(folder_path, file_name), 'r', encoding='utf-8') as f:
            har_data = json.load(f)

        # Loop over each entry in the HAR file
        for entry in har_data.get('log', {}).get('entries', []):
            request = entry.get('request', {})
            method = request.get('method', '')
            url = request.get('url', '')
            
            # Only consider GET and POST requests
            if method in ['GET', 'POST']:
                # Extract query parameters (if any)
                query_params = request.get('queryString', [])
                # Extract headers
                headers = request.get('headers', [])
                # Extract POST data, if applicable
                post_data = request.get('postData', None)
                
                qpt = tuple((param.get('name'), param.get('value')) for param in query_params)
                pdt = json.dumps(post_data, sort_keys=True) if post_data else None
                req_id = (method, url, qpt, pdt)
                
                if req_id not in seen_requests:
                    seen_requests.add(req_id)
                    api_requests.append({
                        'method': method,
                        'url': url,
                        'query_params': query_params,
                        'headers': headers,
                        'post_data': post_data,
                    })

# Display the extracted API requests
for idx, req in enumerate(api_requests, start=1):
    print(f"--- API Request {idx} ---")
    print(f"Method: {req['method']}")
    print(f"URL: {req['url']}")
    
    if req['query_params']:
        print("Query Parameters:")
        for param in req['query_params']:
            print(f"  - {param.get('name')}: {param.get('value')}")
    
    if req['post_data']:
        print("POST Data:")
        print(req['post_data'])
    
    print("Headers:")
    for header in req['headers']:
        print(f"  - {header.get('name')}: {header.get('value')}")
    
    print("\n")

# Write the unique API requests to a text file
with open(os.path.join(folder_path, "unique_api_requests.txt"), "w", encoding="utf-8") as out_file:
    for idx, req in enumerate(api_requests, start=1):
        out_file.write(f"--- API Request {idx} ---\n")
        out_file.write(f"Method: {req['method']}\n")
        out_file.write(f"URL: {req['url']}\n")
        
        if req['query_params']:
            out_file.write("Query Parameters:\n")
            for param in req['query_params']:
                out_file.write(f"  - {param.get('name')}: {param.get('value')}\n")
        
        if req['post_data']:
            out_file.write("POST Data:\n")
            out_file.write(f"{req['post_data']}\n")
        
        out_file.write("Headers:\n")
        for header in req['headers']:
            out_file.write(f"  - {header.get('name')}: {header.get('value')}\n")
        
        out_file.write("\n")
